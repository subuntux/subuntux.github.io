import sqlite3
import subprocess

db_path = "/data/data/com.termux/files/usr/shared/pyterm/db/links.db"

def open_matching_url(search_term):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT url FROM links WHERE name LIKE ?", ('%' + search_term + '%',))
    result = c.fetchone()
    conn.close()
    
    if result:
        url = result[0]
        subprocess.run(["termux-open-url", url])
    else:
        print("Invalid Search")
        
search_term = input("What do you want to search for? ")
open_matching_url(search_term)
