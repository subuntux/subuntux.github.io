#!/bin/bash

read -p "name-| " name
read -p "url-| " url

sqlite3 /data/data/com.termux/files/usr/shared/pyterm/db/links.db "INSERT INTO links (name, url) VALUES ('$name', '$url');"
